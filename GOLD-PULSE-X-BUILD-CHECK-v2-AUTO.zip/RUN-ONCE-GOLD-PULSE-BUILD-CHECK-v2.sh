#!/usr/bin/env bash
set -u

SELF="$(basename "$0")"
LOG="/tmp/gold-pulse-build-v2.log"

cleanup() {
  rm -f -- "$0" 2>/dev/null || true
}
trap cleanup EXIT

echo
echo "=========================================="
echo " GOLD PULSE X — AUTO BUILD CHECK v2"
echo "=========================================="

if [[ ! -f package.json ]]; then
  echo "❌ ERROR: ต้องรันที่ root ของ gold-pulse-x-v9"
  exit 2
fi

echo "Version: $(node -p "require('./package.json').version" 2>/dev/null || echo unknown)"
echo "Branch : $(git branch --show-current 2>/dev/null || echo unknown)"
echo
echo "กำลังตรวจ Production Build..."

npm run build >"$LOG" 2>&1
CODE=$?

echo
echo "=========================================="

if [[ "$CODE" -eq 0 ]]; then
  echo "✅ BUILD PASS"
  echo "Production build ผ่าน"
  echo "กลับไปรัน Auto Installer R1 ต่อได้"
  echo "=========================================="
  exit 0
fi

echo "❌ BUILD FAIL"
echo "Exit code: $CODE"
echo
echo "===== IMPORTANT BUILD OUTPUT ====="

# Always show a useful tail even if error wording differs.
grep -Ein -B2 -A8 \
  'error|failed|failure|cannot|module|syntax|type|unexpected|invalid|not found|compile|build' \
  "$LOG" 2>/dev/null | tail -n 80 > /tmp/gold-pulse-important-v2.txt || true

if [[ -s /tmp/gold-pulse-important-v2.txt ]]; then
  cat /tmp/gold-pulse-important-v2.txt
else
  tail -n 60 "$LOG"
fi

echo
echo "===== END ====="
echo "ไม่ได้ Commit / Push / แก้ Production"
echo "ส่งภาพตั้งแต่ BUILD FAIL ลงมาถึง END มาให้ผม"
exit "$CODE"
