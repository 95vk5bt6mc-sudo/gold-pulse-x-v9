#!/usr/bin/env bash
set -Eeuo pipefail

INSTALL_SUCCESS=0
INSTALLER_ZIP="GOLD-PULSE-X-v11.0-R1-AUTO-INSTALL.zip"

cleanup_installer() {
  local code=$?
  if [[ "${INSTALL_SUCCESS:-0}" == "1" && "$code" -eq 0 ]]; then
    printf '\n\033[1;32m%s\033[0m\n' "Cleanup: ลบ Auto Installer หลังติดตั้งสำเร็จ"
    rm -f -- "$INSTALLER_ZIP" 2>/dev/null || true
    rm -f -- "$0" 2>/dev/null || true
  else
    printf '\n\033[1;33m%s\033[0m\n' "Installer ถูกเก็บไว้ เพราะการติดตั้งยังไม่สำเร็จครบทุกขั้น"
  fi
}
trap cleanup_installer EXIT


say(){ printf '\n\033[1;36m%s\033[0m\n' "$*"; }
ok(){ printf '\n\033[1;32m%s\033[0m\n' "$*"; }
fail(){ printf '\n\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }

[[ -f package.json ]] || fail "เปิด Terminal ที่ root ของ gold-pulse-x-v9 ก่อน"
[[ -d .git ]] || fail "โฟลเดอร์นี้ไม่ใช่ Git repository"
[[ -f lib/intelligence/five-minute-intelligence.js ]] || fail "ไม่พบ v11 Pattern Intelligence engine"

CURRENT_VERSION="$(node -p "require('./package.json').version" 2>/dev/null || true)"
[[ "$CURRENT_VERSION" == "11.0.0" ]] || fail "Patch นี้รองรับ GOLD PULSE X v11.0.0 เท่านั้น (พบ $CURRENT_VERSION)"

SELF="$(basename "$0")"
DIRTY="$(git status --porcelain | grep -v -E "^\\?\\? ${SELF//./\\.}$|^ M ${SELF//./\\.}$|^\\?\\? ${INSTALLER_ZIP//./\\.}$" || true)"
[[ -z "$DIRTY" ]] || fail "มีไฟล์อื่นที่ยังไม่ Commit/Discard กรุณาจัดการก่อน:\n$DIRTY"

say "0/9 ซิงก์ main"
git pull --ff-only origin main || fail "git pull ไม่สำเร็จ"

if [[ -f .github/workflows/gold-pulse-scan.yml ]] && grep -Eq '^[[:space:]]*schedule:' .github/workflows/gold-pulse-scan.yml; then
  fail "GitHub schedule ยังเปิดอยู่ ต้องให้ cron-job.org เป็น scheduler หลักเพียงตัวเดียว"
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR=".git/gold-pulse-backups"
mkdir -p "$BACKUP_DIR"
BACKUP="$BACKUP_DIR/v11.0-before-r1-five-candle-truth-$STAMP.tar.gz"

say "1/9 สำรอง Core เดิม"
tar -czf "$BACKUP" \
  package.json app/page.js app/api/gold/route.js app/api/health/route.js \
  lib/alerts.ts lib/intelligence/five-minute-intelligence.js \
  scripts/test-v11-intelligence.mjs scripts/static-check.mjs \
  2>/dev/null || true
printf 'Backup: %s\n' "$BACKUP"

say "2/9 สร้าง Five-Candle Truth Engine แบบไม่เพิ่ม API call"
cat > lib/intelligence/five-candle-truth.js <<'JS_EOF'
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const finite = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;

function ema(values, period) {
  const out = Array(values.length).fill(null);
  if (values.length < period) return out;
  const k = 2 / (period + 1);
  let current = values.slice(0, period).reduce((sum, value) => sum + value, 0) / period;
  out[period - 1] = current;
  for (let i = period; i < values.length; i += 1) {
    current = values[i] * k + current * (1 - k);
    out[i] = current;
  }
  return out;
}

function rsi(values, period = 14) {
  const out = Array(values.length).fill(null);
  if (values.length <= period) return out;
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i += 1) {
    const d = values[i] - values[i - 1];
    gain += Math.max(d, 0);
    loss += Math.max(-d, 0);
  }
  gain /= period;
  loss /= period;
  out[period] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
  for (let i = period + 1; i < values.length; i += 1) {
    const d = values[i] - values[i - 1];
    gain = (gain * (period - 1) + Math.max(d, 0)) / period;
    loss = (loss * (period - 1) + Math.max(-d, 0)) / period;
    out[i] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
  }
  return out;
}

function atr(candles, period = 14) {
  const tr = candles.map((c, i) => {
    if (i === 0) return c.high - c.low;
    const pc = candles[i - 1].close;
    return Math.max(c.high - c.low, Math.abs(c.high - pc), Math.abs(c.low - pc));
  });
  const out = Array(candles.length).fill(null);
  if (candles.length < period) return out;
  let current = tr.slice(0, period).reduce((s, v) => s + v, 0) / period;
  out[period - 1] = current;
  for (let i = period; i < tr.length; i += 1) {
    current = (current * (period - 1) + tr[i]) / period;
    out[i] = current;
  }
  return out;
}

function macdHistogram(values) {
  const fast = ema(values, 12);
  const slow = ema(values, 26);
  const line = values.map((_, i) => fast[i] != null && slow[i] != null ? fast[i] - slow[i] : null);
  const compact = line.filter((v) => v != null);
  const compactSignal = ema(compact, 9);
  const signal = Array(values.length).fill(null);
  let j = 0;
  for (let i = 0; i < values.length; i += 1) {
    if (line[i] != null) signal[i] = compactSignal[j++];
  }
  return line.map((v, i) => v != null && signal[i] != null ? v - signal[i] : null);
}

function parseBangkokStart(datetime) {
  const text = String(datetime || "").trim();
  if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(text)) return NaN;
  return Date.parse(text.replace(" ", "T") + "+07:00");
}

function sanitize(input) {
  const deduped = new Map();
  for (const c of input || []) {
    const item = {
      datetime: String(c.datetime || ""),
      open: finite(c.open, NaN),
      high: finite(c.high, NaN),
      low: finite(c.low, NaN),
      close: finite(c.close, NaN)
    };
    if (!item.datetime) continue;
    if (![item.open, item.high, item.low, item.close].every(Number.isFinite)) continue;
    if (item.low > Math.min(item.open, item.close) || item.high < Math.max(item.open, item.close)) continue;
    deduped.set(item.datetime, item);
  }
  return [...deduped.values()].sort((a, b) => a.datetime.localeCompare(b.datetime));
}

export function closedFiveMinuteCandles(inputCandles, nowMs = Date.now()) {
  const candles = sanitize(inputCandles);
  if (!candles.length) return candles;
  const startMs = parseBangkokStart(candles.at(-1)?.datetime);
  if (Number.isFinite(startMs) && nowMs < startMs + 5 * 60 * 1000) return candles.slice(0, -1);
  return candles;
}

function buildSeries(candles) {
  const close = candles.map((c) => c.close);
  return {
    ema9: ema(close, 9),
    ema21: ema(close, 21),
    ema50: ema(close, 50),
    rsi: rsi(close),
    atr: atr(candles),
    macd: macdHistogram(close)
  };
}

function featureVector(candles, index, series) {
  if (index < 55) return null;
  const c = candles[index];
  const a = Math.max(finite(series.atr[index], 0), 1e-9);
  if (![series.ema9[index], series.ema21[index], series.ema50[index], series.rsi[index]].every(Number.isFinite)) return null;
  const range = Math.max(c.high - c.low, 1e-9);
  const bodyHigh = Math.max(c.open, c.close);
  const bodyLow = Math.min(c.open, c.close);
  const returns = [1, 2, 3, 6, 12].map((n) => clamp((c.close - candles[index - n].close) / a, -8, 8));
  const recent = candles.slice(index - 20, index);
  const recentHigh = Math.max(...recent.map((x) => x.high));
  const recentLow = Math.min(...recent.map((x) => x.low));
  const recentAtr = series.atr.slice(Math.max(0, index - 30), index).filter(Number.isFinite);
  const avgAtr = recentAtr.length ? recentAtr.reduce((s, v) => s + v, 0) / recentAtr.length : a;
  return [
    clamp((c.close - c.open) / a, -4, 4),
    clamp((c.high - bodyHigh) / a, 0, 4),
    clamp((bodyLow - c.low) / a, 0, 4),
    clamp(((c.close - c.low) / range - 0.5) * 2, -1, 1),
    ...returns,
    clamp((series.ema9[index] - series.ema21[index]) / a, -8, 8),
    clamp((series.ema21[index] - series.ema50[index]) / a, -10, 10),
    clamp((series.ema9[index] - series.ema9[index - 3]) / a, -5, 5),
    clamp((series.rsi[index] - 50) / 25, -2, 2),
    clamp(finite(series.macd[index], 0) / a, -4, 4),
    clamp(a / Math.max(avgAtr, 1e-9), 0.25, 4),
    clamp((recentHigh - c.close) / a, -2, 12),
    clamp((c.close - recentLow) / a, -2, 12)
  ];
}

function distance(a, b) {
  let total = 0;
  for (let i = 0; i < a.length; i += 1) {
    const d = a[i] - b[i];
    total += d * d;
  }
  return Math.sqrt(total / a.length);
}

function futureCandleOutcome(candles, index, horizon, atrValue) {
  if (index + horizon >= candles.length) return "SIDEWAY";
  const future = candles[index + horizon];
  const body = future.close - future.open;
  const threshold = Math.max(atrValue * 0.045, 0.03);
  if (body >= threshold) return "UP";
  if (body <= -threshold) return "DOWN";
  return "SIDEWAY";
}

function probabilities(matches, horizon) {
  const counts = { UP: 1.5, DOWN: 1.5, SIDEWAY: 1.5 };
  for (const match of matches) counts[match.outcomes[horizon - 1]] += match.weight;
  const total = counts.UP + counts.DOWN + counts.SIDEWAY;
  const up = Math.round(counts.UP / total * 100);
  const down = Math.round(counts.DOWN / total * 100);
  return { up, down, sideway: 100 - up - down };
}

function buildMemory(candles, series, currentIndex = candles.length - 1) {
  const current = featureVector(candles, currentIndex, series);
  if (!current) return null;
  const raw = [];

  for (let index = 55; index <= currentIndex - 5; index += 1) {
    const vector = featureVector(candles, index, series);
    if (!vector) continue;
    const d = distance(current, vector);
    const similarity = clamp(1 - d / 3.2, 0, 1);
    const a = Math.max(finite(series.atr[index], 0), 0.01);
    raw.push({
      index,
      distance: d,
      similarity,
      outcomes: [1, 2, 3, 4, 5].map((h) => futureCandleOutcome(candles, index, h, a))
    });
  }

  raw.sort((a, b) => a.distance - b.distance);
  const target = Math.min(120, Math.max(40, Math.floor(raw.length * 0.22)));
  const selected = raw.slice(0, target).map((item) => ({
    ...item,
    weight: Math.pow(Math.max(0.04, item.similarity), 3) / Math.max(0.08, item.distance)
  }));

  const forecasts = [1, 2, 3, 4, 5].map((horizon) => {
    const p = probabilities(selected, horizon);
    const ranked = Object.entries(p).sort((a, b) => b[1] - a[1]);
    const [leader, runnerUp] = ranked;
    const rawDirection = leader[0] === "up" ? "BUY" : leader[0] === "down" ? "SELL" : "WAIT";
    const direction = leader[1] >= 43 && leader[1] - runnerUp[1] >= 6 ? rawDirection : "WAIT";
    return {
      candle: horizon,
      minutesAhead: horizon * 5,
      direction,
      confidence: leader[1],
      edge: leader[1] - runnerUp[1],
      probabilities: p
    };
  });

  const averageSimilarity = selected.length
    ? Math.round(selected.reduce((s, m) => s + m.similarity, 0) / selected.length * 100)
    : 0;

  return {
    engine: "Five-Candle DNA Weighted KNN",
    sourceCandles: currentIndex + 1,
    usableHistoricalCases: raw.length,
    matchedCases: selected.length,
    averageSimilarity,
    forecasts
  };
}

function directionToOutcome(direction) {
  if (direction === "BUY") return "UP";
  if (direction === "SELL") return "DOWN";
  return "SIDEWAY";
}

function walkForward(candles, series) {
  const perCandle = [1, 2, 3, 4, 5].map((candle) => ({ candle, samples: 0, correct: 0, directional: 0, directionalCorrect: 0 }));
  let anchors = 0;
  let predictions = 0;
  let correct = 0;
  let directional = 0;
  let directionalCorrect = 0;
  let exactFiveSamples = 0;
  let exactFiveCorrect = 0;
  const start = Math.max(125, candles.length - 120);
  const end = candles.length - 6;

  for (let anchor = start; anchor <= end; anchor += 2) {
    const memory = buildMemory(candles, series, anchor);
    if (!memory?.forecasts?.length) continue;
    anchors += 1;
    let allFiveDirectional = true;
    let allFiveCorrect = true;

    for (let h = 1; h <= 5; h += 1) {
      const forecast = memory.forecasts[h - 1];
      const predicted = directionToOutcome(forecast.direction);
      const a = Math.max(finite(series.atr[anchor], 0), 0.01);
      const actual = futureCandleOutcome(candles, anchor, h, a);
      const slot = perCandle[h - 1];
      slot.samples += 1;
      predictions += 1;
      if (predicted === actual) {
        slot.correct += 1;
        correct += 1;
      }
      if (forecast.direction === "BUY" || forecast.direction === "SELL") {
        slot.directional += 1;
        directional += 1;
        if (predicted === actual) {
          slot.directionalCorrect += 1;
          directionalCorrect += 1;
        } else {
          allFiveCorrect = false;
        }
      } else {
        allFiveDirectional = false;
        allFiveCorrect = false;
      }
    }

    if (allFiveDirectional) {
      exactFiveSamples += 1;
      if (allFiveCorrect) exactFiveCorrect += 1;
    }
  }

  return {
    mode: "no-lookahead-walk-forward",
    anchors,
    allAccuracy: predictions ? Math.round(correct / predictions * 100) : null,
    directionalAccuracy: directional ? Math.round(directionalCorrect / directional * 100) : null,
    directionalCoverage: predictions ? Math.round(directional / predictions * 100) : 0,
    exactFive: {
      samples: exactFiveSamples,
      correct: exactFiveCorrect,
      accuracy: exactFiveSamples ? Math.round(exactFiveCorrect / exactFiveSamples * 100) : null
    },
    perCandle: perCandle.map((slot) => ({
      candle: slot.candle,
      samples: slot.samples,
      accuracy: slot.samples ? Math.round(slot.correct / slot.samples * 100) : null,
      directionalSamples: slot.directional,
      directionalAccuracy: slot.directional ? Math.round(slot.directionalCorrect / slot.directional * 100) : null,
      directionalCoverage: slot.samples ? Math.round(slot.directional / slot.samples * 100) : 0
    }))
  };
}

function integrity(candles) {
  let gaps = 0;
  for (let i = 1; i < candles.length; i += 1) {
    const a = parseBangkokStart(candles[i - 1].datetime);
    const b = parseBangkokStart(candles[i].datetime);
    if (Number.isFinite(a) && Number.isFinite(b) && b - a > 5 * 60 * 1000 + 1000) gaps += 1;
  }
  return { ok: gaps === 0, gaps, candles: candles.length };
}

export function analyzeFiveCandleTruth(inputCandles) {
  const sanitized = sanitize(inputCandles);
  const candles = closedFiveMinuteCandles(sanitized);
  const droppedOpenCandle = sanitized.length - candles.length;
  if (candles.length < 140) {
    return { ready: false, reason: "ต้องมีแท่ง 5M ที่ปิดแล้วอย่างน้อย 140 แท่ง", closedCandlePolicy: "closed-only" };
  }
  const series = buildSeries(candles);
  const memory = buildMemory(candles, series);
  const validation = walkForward(candles, series);
  return {
    ready: true,
    engine: "GOLD PULSE X v11.0 R1 Five-Candle Truth",
    mode: "shadow-audit",
    changesTradeDecision: false,
    closedCandlePolicy: "closed-only",
    droppedOpenCandle,
    lastClosedCandleAt: candles.at(-1)?.datetime || null,
    integrity: integrity(candles),
    patternMemory: memory,
    validation,
    note: "ทำนายทิศของแท่ง 5M ถัดไป #1-#5 และวัดแบบ no-lookahead walk-forward; เป็นความน่าจะเป็น ไม่ใช่การรับประกันอนาคต"
  };
}
JS_EOF

say "3/9 เชื่อมเข้ากับ API แบบ Shadow Audit + Closed Candle Lock"
python3 - <<'PY_EOF'
from pathlib import Path

def req(cond, msg):
    if not cond:
        raise SystemExit(f"ERROR: {msg}")

# API route
p = Path("app/api/gold/route.js")
s = p.read_text()
base_import = 'import { analyzeFiveMinuteIntelligence, applyFiveMinuteIntelligenceOverlay } from "../../../lib/intelligence/five-minute-intelligence";'
new_import = base_import + '\nimport { analyzeFiveCandleTruth, closedFiveMinuteCandles } from "../../../lib/intelligence/five-candle-truth";'
if 'from "../../../lib/intelligence/five-candle-truth"' not in s:
    req(base_import in s, "ไม่พบ v11 intelligence import ใน app/api/gold/route.js")
    s = s.replace(base_import, new_import, 1)

old_build = '''  const oneAnalysis = analyze([...m1], 5);
  const fiveAnalysis = analyze([...m5], 5);
  const fiveMinuteIntelligence = analyzeFiveMinuteIntelligence(m5);
  const baseTradeDecision = combinedTradeDecision(oneAnalysis, fiveAnalysis, m1.at(-1)?.close || 0);
  const tradeDecision = applyFiveMinuteIntelligenceOverlay(baseTradeDecision, fiveMinuteIntelligence);
  const smartFree = buildSmartFreeContext(tradeDecision, oneAnalysis, fiveAnalysis);'''
new_build = '''  const oneAnalysis = analyze([...m1], 5);
  const m5Closed = closedFiveMinuteCandles(m5);
  const fiveAnalysis = analyze([...m5Closed], 5);
  const fiveMinuteIntelligence = analyzeFiveMinuteIntelligence(m5Closed);
  const fiveCandleTruth = analyzeFiveCandleTruth(m5Closed);
  const baseTradeDecision = combinedTradeDecision(oneAnalysis, fiveAnalysis, m1.at(-1)?.close || 0);
  const tradeDecision = applyFiveMinuteIntelligenceOverlay(baseTradeDecision, fiveMinuteIntelligence);
  const smartFree = buildSmartFreeContext(tradeDecision, oneAnalysis, fiveAnalysis);'''
if 'const fiveCandleTruth = analyzeFiveCandleTruth' not in s:
    req(old_build in s, "ไม่พบ v11 buildPayload block ที่คาดไว้")
    s = s.replace(old_build, new_build, 1)

old_payload = '    fiveMinute: { candles: m5.slice(-140), analysis: fiveAnalysis },\n    fiveMinuteIntelligence,\n    tradeDecision'
new_payload = '    fiveMinute: { candles: m5.slice(-140), analysis: fiveAnalysis },\n    fiveMinuteIntelligence,\n    fiveCandleTruth,\n    tradeDecision'
if '    fiveCandleTruth,' not in s:
    req(old_payload in s, "ไม่พบตำแหน่งเพิ่ม fiveCandleTruth ใน payload")
    s = s.replace(old_payload, new_payload, 1)
p.write_text(s)

# Health
p = Path("app/api/health/route.js")
s = p.read_text()
s = s.replace('app: "GOLD PULSE X v11.0 PATTERN INTELLIGENCE 5M"', 'app: "GOLD PULSE X v11.0 R1 FIVE-CANDLE TRUTH"', 1)
if 'fiveCandleTruth:' not in s:
    marker = '    patternIntelligence: {'
    req(marker in s, "ไม่พบ patternIntelligence ใน Health API")
    block = '''    fiveCandleTruth: {
      enabled: true,
      mode: "shadow-audit",
      changesTradeDecision: false,
      target: "future 5M candle #1-#5 body direction",
      closedCandlesOnly: true,
      validation: "no-lookahead walk-forward",
      extraUpstreamRequests: 0,
      paidServicesAdded: 0
    },
'''
    s = s.replace(marker, block + marker, 1)
p.write_text(s)

# Dashboard panel
p = Path("app/page.js")
s = p.read_text()
if '5-CANDLE TRUTH AUDIT' not in s:
    marker = '      <section className="panel reasons">'
    req(marker in s, "ไม่พบ reasons panel ใน Dashboard")
    panel = '''      {data?.fiveCandleTruth?.ready && (
        <section className="panel logic">
          <p className="eyebrow">5-CANDLE TRUTH AUDIT · CLOSED CANDLES ONLY</p>
          <h2>ทำนายแท่ง 5 นาทีถัดไป #1–#5</h2>
          <p>{(data.fiveCandleTruth.patternMemory?.forecasts || []).slice(0,5).map((f) => `#${f.candle} ${f.direction} ${f.confidence}%`).join(" · ") || "ยังไม่มี Forecast"}</p>
          <p>Walk-forward directional accuracy {data.fiveCandleTruth.validation?.directionalAccuracy ?? "—"}% · coverage {data.fiveCandleTruth.validation?.directionalCoverage ?? "—"}% · exact-5 {data.fiveCandleTruth.validation?.exactFive?.accuracy ?? "—"}% · anchors {data.fiveCandleTruth.validation?.anchors ?? 0}</p>
          <p>Last closed candle {data.fiveCandleTruth.lastClosedCandleAt || "—"} · Open candle dropped {data.fiveCandleTruth.droppedOpenCandle || 0} · Shadow only: ไม่เปลี่ยน Signal Core เดิม</p>
        </section>
      )}

'''
    s = s.replace(marker, panel + marker, 1)
p.write_text(s)

# LINE: informational only; does not alter gates.
p = Path("lib/alerts.ts")
s = p.read_text()
if '5C future' not in s:
    marker = '    `Entry reference ${numberText(d.entryPrice)}`,'
    req(marker in s, "ไม่พบ Entry reference ใน LINE formatter")
    lines = '''    `5C future ${(payload?.fiveCandleTruth?.patternMemory?.forecasts || []).slice(0,5).map((f) => `#${f.candle}:${f.direction}`).join(" ") || "—"}`,
    `5C truth dir ${payload?.fiveCandleTruth?.validation?.directionalAccuracy ?? "—"}% · coverage ${payload?.fiveCandleTruth?.validation?.directionalCoverage ?? "—"}% · exact5 ${payload?.fiveCandleTruth?.validation?.exactFive?.accuracy ?? "—"}%`,
'''
    s = s.replace(marker, lines + marker, 1)
p.write_text(s)

# Static check: require the new module.
p = Path("scripts/static-check.mjs")
s = p.read_text()
if 'lib/intelligence/five-candle-truth.js' not in s:
    marker = '  "lib/intelligence/five-minute-intelligence.js",'
    req(marker in s, "ไม่พบ intelligence marker ใน static-check")
    s = s.replace(marker, marker + '\n  "lib/intelligence/five-candle-truth.js",', 1)
p.write_text(s)
PY_EOF

say "4/9 แก้ Double-counting ของ v11 Overlay แบบ Compatibility-safe"
python3 - <<'PY_EOF'
from pathlib import Path
p = Path("lib/intelligence/five-minute-intelligence.js")
s = p.read_text()

# General overlay bias previously included fake-breakout/divergence/structure and then counted them again.
# Here general bias is reduced to Pattern Memory forecasts only; dedicated evidence blocks remain unchanged.
old = '  const biasDirection = String(intelligence.bias?.direction || "WAIT").toUpperCase();'
new = '''  const patternForecasts = intelligence.patternMemory?.forecasts || [];
  let patternBuyVotes = 0;
  let patternSellVotes = 0;
  if (patternForecasts[0]?.direction === "BUY") patternBuyVotes += 2;
  if (patternForecasts[0]?.direction === "SELL") patternSellVotes += 2;
  if (patternForecasts[1]?.direction === "BUY") patternBuyVotes += 1;
  if (patternForecasts[1]?.direction === "SELL") patternSellVotes += 1;
  const patternEdge = Math.abs(patternBuyVotes - patternSellVotes);
  const biasDirection = patternBuyVotes - patternSellVotes >= 2
    ? "BUY"
    : patternSellVotes - patternBuyVotes >= 2
      ? "SELL"
      : "WAIT";'''
if 'const patternForecasts = intelligence.patternMemory?.forecasts || [];' not in s:
    if old not in s:
        raise SystemExit("ERROR: ไม่พบ biasDirection marker สำหรับแก้ double-counting")
    s = s.replace(old, new, 1)
    s = s.replace('finite(intelligence.bias?.edge, 0)', 'finite(patternEdge, 0)')
p.write_text(s)
PY_EOF

say "5/9 สร้าง Regression Test ของ 5 แท่ง + Closed Candle"
cat > scripts/test-v11-r1-five-candle-truth.mjs <<'TEST_EOF'
import assert from "node:assert/strict";
import { analyzeFiveCandleTruth, closedFiveMinuteCandles } from "../lib/intelligence/five-candle-truth.js";

const candles = [];
let price = 4000;
for (let i = 0; i < 520; i += 1) {
  const wave = Math.sin(i / 17) * 0.18 + Math.sin(i / 5) * 0.06 + Math.cos(i / 11) * 0.04;
  const open = price;
  const close = open + wave;
  const high = Math.max(open, close) + 0.16 + Math.abs(Math.sin(i)) * 0.08;
  const low = Math.min(open, close) - 0.16 - Math.abs(Math.cos(i)) * 0.08;
  price = close;
  candles.push({
    datetime: new Date(Date.UTC(2026, 0, 1, 0, i * 5)).toISOString().slice(0, 19).replace("T", " "),
    open, high, low, close
  });
}

const truth = analyzeFiveCandleTruth(candles);
assert.equal(truth.ready, true);
assert.equal(truth.mode, "shadow-audit");
assert.equal(truth.changesTradeDecision, false);
assert.equal(truth.closedCandlePolicy, "closed-only");
assert.equal(truth.patternMemory.forecasts.length, 5);
assert.equal(truth.validation.perCandle.length, 5);
assert.equal(truth.validation.mode, "no-lookahead-walk-forward");
assert.ok(truth.validation.anchors > 0);
assert.ok(truth.validation.directionalCoverage >= 0 && truth.validation.directionalCoverage <= 100);
assert.ok(truth.validation.directionalAccuracy == null || (truth.validation.directionalAccuracy >= 0 && truth.validation.directionalAccuracy <= 100));

const partial = [
  { datetime: "2026-08-12 15:05:00", open: 1, high: 2, low: 0.5, close: 1.5 },
  { datetime: "2026-08-12 15:10:00", open: 1.5, high: 1.6, low: 1.4, close: 1.55 }
];
const locked = closedFiveMinuteCandles(partial, Date.parse("2026-08-12T15:10:04+07:00"));
assert.equal(locked.length, 1);
assert.equal(locked[0].datetime, "2026-08-12 15:05:00");

console.log("✅ v11.0 R1 Five-Candle Truth tests passed");
TEST_EOF

say "6/9 สร้าง Build Report"
cat > BUILD-REPORT-v11.0-R1-FIVE-CANDLE-TRUTH.md <<'REPORT_EOF'
# GOLD PULSE X v11.0 R1 — FIVE-CANDLE TRUTH

## Why this patch exists
Cron runs a few seconds after each 5-minute boundary. A newly opened 5M bucket must not be treated as a completed candle. The existing v11 Pattern Intelligence also forecasts only 1/2/3 horizons and measures cumulative close movement, which is not the same as predicting the body direction of five unseen candles.

## R1 changes
- Adds five future 5M candle forecasts: #1, #2, #3, #4, #5.
- Target is each future candle body direction: BUY / SELL / WAIT (noise body).
- Adds closed-candle lock. Example: a scan at 15:10:04 uses 15:05 as the last completed 5M candle, never the just-opened 15:10 bucket.
- Adds no-lookahead walk-forward validation from the same real market window already fetched by GOLD PULSE.
- Reports directional accuracy, prediction coverage, per-candle accuracy, and exact-five accuracy.
- Runs in shadow-audit mode: five-candle predictions do not directly alter BUY/SELL entry gates in R1.
- Fixes v11 evidence double-counting: Pattern Memory drives the general intelligence bias; fake breakout/divergence/structure continue through their dedicated checks instead of being counted inside bias and again afterward.
- Keeps Classic 9.8 Pro Plus, PULSE-off policy, Risk HIGH blocking, LINE flow, cron-job.org cadence, and existing API architecture.

## Cost / privacy / security
- 0 new upstream market-data requests.
- 0 new packages.
- 0 databases / Redis.
- 0 paid APIs or services added.
- 0 new secrets.
- TWELVE_DATA_API_KEY remains server-side in Vercel Environment Variables.
- No market data or signal data is sent to a new third party by this patch.

## Important
No statistical system can guarantee the direction of five unseen market candles. R1 is intentionally designed to expose measured out-of-sample accuracy instead of presenting model confidence as proven accuracy.
REPORT_EOF

say "7/9 ตรวจ Syntax / Regression / Static Check"
node --check lib/intelligence/five-candle-truth.js || fail "five-candle-truth syntax ไม่ผ่าน"
node --check lib/intelligence/five-minute-intelligence.js || fail "v11 intelligence syntax ไม่ผ่าน"
node --check app/api/gold/route.js || fail "Gold API syntax ไม่ผ่าน"
node --check app/api/health/route.js || fail "Health API syntax ไม่ผ่าน"
node scripts/test-v11-intelligence.mjs || fail "v11 regression เดิมไม่ผ่าน"
node scripts/test-v11-r1-five-candle-truth.mjs || fail "R1 five-candle regression ไม่ผ่าน"
node scripts/static-check.mjs || fail "Static check ไม่ผ่าน"
git diff --check || fail "git diff --check ไม่ผ่าน"

say "8/9 ตรวจ Production Build"
if [[ -x node_modules/.bin/next ]]; then
  npm run build || fail "Production build ไม่ผ่าน — จะไม่ Commit"
else
  printf 'INFO: ไม่พบ node_modules/.bin/next จึงข้าม local build; Vercel จะติดตั้ง dependencies และ build หลัง push\n'
fi

say "9/9 Commit + Push"
git add \
  lib/intelligence/five-candle-truth.js \
  lib/intelligence/five-minute-intelligence.js \
  app/api/gold/route.js app/api/health/route.js app/page.js \
  lib/alerts.ts scripts/static-check.mjs scripts/test-v11-r1-five-candle-truth.mjs \
  BUILD-REPORT-v11.0-R1-FIVE-CANDLE-TRUTH.md

if git diff --cached --quiet; then
  ok "ไม่มีไฟล์เปลี่ยน — R1 ถูกติดตั้งอยู่แล้ว"
  INSTALL_SUCCESS=1
  exit 0
fi

if [[ -z "$(git config user.name || true)" ]]; then git config user.name "GOLD PULSE Updater"; fi
if [[ -z "$(git config user.email || true)" ]]; then git config user.email "gold-pulse-updater@users.noreply.github.com"; fi

git commit -m "Harden v11 with five-candle truth audit" || fail "Commit ไม่สำเร็จ"
git push origin HEAD:main || fail "Push ไม่สำเร็จ"

INSTALL_SUCCESS=1
ok "SUCCESS: GOLD PULSE X v11.0 R1 FIVE-CANDLE TRUTH pushed."
printf '\nหลัง Vercel deploy ให้ตรวจ:\n'
printf '1) /api/health ต้องขึ้น v11.0 R1 FIVE-CANDLE TRUTH\n'
printf '2) Dashboard ต้องมี 5-CANDLE TRUTH AUDIT\n'
printf '3) Forecast ต้องมี #1 #2 #3 #4 #5\n'
printf '4) Scan หลัง boundary ไม่ควรใช้แท่งที่เพิ่งเปิดเป็นแท่งปิด\n'
printf '5) LINE ต้องมี 5C future + 5C truth\n'
printf '6) ค่า Truth เป็น walk-forward จริง ไม่ใช่ Model estimate\n'
printf '\nR1 ยังไม่ให้ Five-Candle Truth เปลี่ยน Entry Gate โดยตรง จนกว่าจะมีหลักฐานความแม่นพอ\n'
